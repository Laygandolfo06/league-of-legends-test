/****************************************** CHAMP ************************************************/

/**
$id("list-champs").addEventListener("click", e => {
	for (let target = e.target; target != e.currentTarget && target && target != this; target = target.parentNode) {
		if (target && target.matches("li")) {
			

			break;
		}
	}
});
*/